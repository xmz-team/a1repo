#
#
# official.a1.ad.expand.sh
# Created by AD on 15/12/25
# Copyright (c) 2025 AD All rights reserved.
# Credit to "飘散的烟(QQ: 479011600)" for the optimized script.
#
#

SYSCTL="$jbsbin/sysctl"

ad_a1_optimize() {
    # 虚拟节点最大值
    $SYSCTL kern.maxvnodes=100000
    # 后台保留策略
    $SYSCTL kern.memorystatus_sysprocs_idle_delay_time=0
    $SYSCTL kern.memorystatus_apps_idle_delay_time=0
    $SYSCTL kern.memorystatus_kill_on_sustained_pressure_delay_ms=128304000
    # 页面处理
    $SYSCTL kern.vm_max_batch=512
    # 内存阈值(不適合所有人所以註釋掉,因為可能會導致無故註銷或者重啟用戶空間)
    # 如果你看到了並且覺得適合你可以取消掉注釋
    # $SYSCTL kern.vm_page_free_target=3000
    # $SYSCTL kern.vm_page_free_min=2000
    # $SYSCTL kern.vm_page_free_reserved=512
    # 进程限制
    $SYSCTL kern.maxprocperuid=2000
    # 网络参数
    $SYSCTL net.inet.tcp.sendspace=262144
    $SYSCTL net.inet.tcp.recvspace=393216
    $SYSCTL net.link.ether.inet.max_age=600
    $SYSCTL net.inet.tcp.delayed_ack=0
    $SYSCTL net.inet.tcp.keepidle=14400000
    $SYSCTL net.inet.tcp.always_keepalive=1
    $SYSCTL net.inet.tcp.keepcnt=16
    # 压缩策略
    $SYSCTL vm.compressor_thrashing_threshold_per_10msecs=150
    $SYSCTL vm.compressor_eval_period_in_msecs=750
    # 虚拟内存
    $SYSCTL vm.user_wire_limit=5368709120
    $SYSCTL vm.global_user_wire_limit=5368709120
    # 工作队列
    $SYSCTL kern.wq_max_threads=5120
    $SYSCTL kern.wq_max_constrained_threads=96
    # Socket连接
    $SYSCTL kern.ipc.somaxconn=512
    # 后台限制
    $SYSCTL debug.lowpri_throttle_enabled=0
}

ad_a1_optimize
